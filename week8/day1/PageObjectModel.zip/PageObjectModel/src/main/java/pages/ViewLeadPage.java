package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import base.ProjectSpecificMethods;

public class ViewLeadPage extends ProjectSpecificMethods {
	public ViewLeadPage(ChromeDriver driver) {
		this.driver = driver;
	}

	public void verifyFirstName(String expName) {
		String actName = driver.findElement(By.id("viewLead_firstName_sp")).getText();
		Assert.assertEquals(actName, expName);
	}

}
