package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.HomePage;
import pages.LoginPage;

public class CreateLead extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setFileName() {
		excelFileName = "CreateLead";
	}
	
	@Test(dataProvider = "getData")
	public void runLoginLogout(String username, String password, String company, String firstName, String lastName) throws InterruptedException {
		
		LoginPage lp = new LoginPage(driver);
		
		lp.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.clickCrmSfa()
		.clickLeadsLink()
		.clickCreateLeadLink()
		.enterFirstName(firstName) // firstName
		.enterLastName(lastName) //lastName
		.enterCompanyName(company) //company
		.clickCreateLeadButton()
		.verifyFirstName(firstName);

	}
	

}
