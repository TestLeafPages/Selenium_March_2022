package testcases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.HomePage;
import pages.LoginPage;

public class LoginAndLogout extends ProjectSpecificMethods{
	
	@Test
	public void runLoginLogout() throws InterruptedException {
		System.out.println(driver);
		LoginPage lp = new LoginPage(driver);
		
		lp.enterUsername("Demosalesmanager")
		.enterPassword("crmsfa")
		.clickLoginButton();
	//	.clickLogoutButton();

	}
	

}
