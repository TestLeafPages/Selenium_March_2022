package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class MyLeadsPage extends ProjectSpecificMethods {
	public MyLeadsPage(WebDriver driver) {
		this.driver = driver;
	}

	public CreateLeadPage clickCreateLeadLink() {
		driver.findElement(By.linkText(prop1.getProperty("link_create_lead"))).click();
		return new CreateLeadPage(driver);

	}

}
