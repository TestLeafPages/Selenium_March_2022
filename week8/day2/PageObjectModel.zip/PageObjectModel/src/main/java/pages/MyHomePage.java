package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class MyHomePage extends ProjectSpecificMethods {
	public MyHomePage(WebDriver driver) {
		this.driver = driver;
	}

	public MyLeadsPage clickLeadsLink() {
		driver.findElement(By.linkText(prop1.getProperty("link_leads"))).click();
		return new MyLeadsPage(driver);
	}

}
