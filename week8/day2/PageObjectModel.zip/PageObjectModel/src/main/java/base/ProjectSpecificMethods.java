package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ReadExcel;


public class ProjectSpecificMethods {
	
	public WebDriver driver;
	
	public String excelFileName; // null value
	public static Properties prop1;

	@DataProvider(name="getData", indices = 0, parallel = true)
	public String[][] fetchData() throws IOException {
		return ReadExcel.readData(excelFileName); // CreateLead , EditLead
	}

	@Parameters("browser")
	@BeforeMethod
	public void preCondition(String browser) throws IOException {
		if (browser.equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		} else if (browser.equalsIgnoreCase("edge")) {
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
		} else if (browser.equalsIgnoreCase("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		}
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream(new File("./src/main/resources/application.properties"));
		prop.load(fis);
		String url = prop.getProperty("url");
		driver.get(url);
		
		String lang = prop.getProperty("lang");
		
		prop1 = new Properties();
		FileInputStream fis1 = new FileInputStream(new File("./src/main/resources/"+lang+".properties"));
		prop1.load(fis1);
		
	}

	@AfterMethod
	public void postCondition() {
		driver.close();

	}
	
}
