package testcases;

public class LearnExceptionHandling {

	public static void main(String[] args) {
		
		int x = 10;
		int y = 2;
		int[] a = {10, 20, 30};
		
		try {
			System.out.println(x/y);
			System.out.println(a[2]);
		} catch (ArithmeticException e) {
			System.out.println("Exception Occurred " + e);
			if (y ==0) {
				System.out.println(x/1);
			}
		} catch (Exception e) {
			System.out.println("Out of Bound");
		} finally {
			System.out.println("In finally block");
		}
		
		System.out.println("Last line of code");
	}

}
