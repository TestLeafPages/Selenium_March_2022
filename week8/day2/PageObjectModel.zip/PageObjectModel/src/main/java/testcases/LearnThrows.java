package testcases;

import org.openqa.selenium.NoSuchElementException;

public class LearnThrows {

	public static void main(String[] args) throws InterruptedException {
		simpleMethod();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static void simpleMethod() throws InterruptedException {
		Thread.sleep(1000);
		
		try {
			throw new NoSuchElementException("Fail");
		} catch (NoSuchElementException e) {
			throw new RuntimeException("Input Field which you are trying to interact is not found");
		} finally {
			System.out.println("Finally");
		}
	}

}
