package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CreateLead extends BaseClass{
	
//	public CreateLead(WebDriver driver) {
//		this.driver = driver;
//	}
	
	@When("Click on CRMSFA link")
	public void clickCRMSFALink() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();

	}

	@Then("MyHome page should be displayed")
	public void verifyMyHomePage() {
		System.out.println("My Home page is displayed");

	}
}
