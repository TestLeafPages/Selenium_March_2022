package steps;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass extends AbstractTestNGCucumberTests{
	
	private static final ThreadLocal<WebDriver> tldriver = new ThreadLocal<WebDriver>();

	public void setDriver(WebDriver driver) {
		tldriver.set(driver);
	}
	
	public WebDriver getDriver() {
		return tldriver.get();
	}
	
//	public WebDriver driver;
	
	@BeforeMethod
	public void preCondition() {
		WebDriverManager.chromedriver().setup();
		setDriver(new ChromeDriver());
//		driver = new ChromeDriver();
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		getDriver().get("http://leaftaps.com/opentaps/control/main");
	}

	@AfterMethod
	public void postCondition() {
		getDriver().close();

	}
}
