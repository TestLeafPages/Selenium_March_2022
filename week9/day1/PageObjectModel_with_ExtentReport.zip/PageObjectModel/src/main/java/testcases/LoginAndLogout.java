package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.HomePage;
import pages.LoginPage;

public class LoginAndLogout extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setValues() {
		excelFileName = "Login";
		testName = "LoginAndLogout";
		testDescription = "Login and Logout for LeafTaps";
		testCategory = "smoke";
		testAuthor = "Hari";
	}
	
	@Test(dataProvider = "getData")
	public void runLoginLogout(String uName, String pWord) throws InterruptedException, IOException {
		System.out.println(driver);
		LoginPage lp = new LoginPage(driver, node);
		
		lp.enterUsername(uName)
		.enterPassword(pWord)
		.clickLoginButton();
	//	.clickLogoutButton();

	}
	

}
