package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.HomePage;
import pages.LoginPage;

public class CreateLead extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setValues() {
		excelFileName = "CreateLead";
		testName = "CreateLead";
		testDescription = "Create lead with mandatory informations";
		testCategory = "functional";
		testAuthor = "Hari";
	}
	
	@Test(dataProvider = "getData")
	public void runLoginLogout(String username, String password, String company, String firstName, String lastName) throws InterruptedException, IOException {
		
		LoginPage lp = new LoginPage(driver,node);
		
		lp.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.clickCrmSfa()
		.clickLeadsLink()
		.clickCreateLeadLink()
		.enterFirstName(firstName) // firstName
		.enterLastName(lastName) //lastName
		.enterCompanyName(company) //company
		.clickCreateLeadButton()
		.verifyFirstName(firstName);

	}
	

}
